#include "Column.h"



// Task 1
Column::Column()
{
    this->next = nullptr;
    this->prev = nullptr;
    this->totalRows = 0;
    this->rowHead = nullptr;
}

// Task 2
Column::Column(Column *prev)
{
    this->next = nullptr;
    this->prev = prev;
    this->totalRows = 0;
    this->rowHead = nullptr;
}

// Task 3
Column::Column(const Column &c)
{
    this->totalRows = c.totalRows;
    this->prev = nullptr;
    this->next = nullptr;
    this->rowHead = c.rowHead != nullptr ? new Cell(*c.rowHead) : nullptr;
}

// Task 4
Column::~Column()
{
    delete rowHead;
}

// Task 5
Cell *Column::findCell(int rowNum)
{    
    if (rowNum+1 > totalRows) {
        return nullptr;
    }
    Cell* current = rowHead;
    int i = 0;
    while (i < rowNum)
    {
        current = current->next;
        i++;
    }
    return current;
}

// Task 6
void Column::modifyCell(int rowNum, const string &value)
{
    if (rowNum < totalRows) {
        Cell* cell = findCell(rowNum);
        cell->value = value;
    }else {
        int i = 0;
        Cell* current = rowHead;
        for (int i = 0; i < rowNum; i++) {
            if (i+1 >= totalRows){
                // append new at the end
                Cell* newCell = new Cell();
                //TODO nullptr may cause edge case
                newCell->value = "";
                current->next = newCell;
                newCell->prev = current;
            }
            current = current-> next;
        }
        current->value = value;
        totalRows = rowNum + 1;
    }
}

// Task 7
void Column::clearCell(int rowNum)
{  
    if (rowNum >= totalRows)
    {
        return;
    }


}

// Task 8
void Column::clearAllCells()
{
    for (int i = totalRows-1; i>0; i--){
        clearCell(i);
    }
    totalRows = 0;
    rowHead = nullptr;
}

// ---------------------- provided functions: DO NOT MODIFY --------------------------
void Column::printColumn() const
{
    // string styles
    string line(12, '-');
    string doubleline(12, '=');
    string space(12, ' ');



    cout << "totalRows: " << totalRows << endl;

    // table header
    cout << doubleline + doubleline << endl;
    cout << " " << std::setw(10) << "" << " ";
    cout << "|" << std::setw(10)  << "column " << "|" <<endl;   
    cout << doubleline + doubleline << endl;

    // table body (row by row)
    Cell* current = rowHead;
    for (int i =0 ; i < totalRows; ++i){
        cout << " " << std::setw(10) << "row " + to_string(i) + " " << " " ;
        cout << "|" << std::setw(10) << current->value << "|" << endl;
        current = current->next;
        cout << doubleline + line << endl;
    }

    cout << endl;

}
