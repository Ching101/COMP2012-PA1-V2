#include "Column.h"

// Task 1
Column::Column()
{

}

// Task 2
Column::Column(Column *prev)
{

}

// Task 3
Column::Column(const Column &c)
{

}

// Task 4
Column::~Column()
{

}

// Task 5
Cell *Column::findCell(int rowNum)
{    

}

// Task 6
void Column::modifyCell(int rowNum, const string &value)
{

}

// Task 7
void Column::clearCell(int rowNum)
{

}

// Task 8
void Column::clearAllCells()
{

}

// ---------------------- provided functions: DO NOT MODIFY --------------------------
void Column::printColumn() const
{
    // string styles
    string line(12, '-');
    string doubleline(12, '=');
    string space(12, ' ');



    cout << "totalRows: " << totalRows << endl;

    // table header
    cout << doubleline + doubleline << endl;
    cout << " " << std::setw(10) << "" << " ";
    cout << "|" << std::setw(10)  << "column " << "|" <<endl;   
    cout << doubleline + doubleline << endl;

    // table body (row by row)
    Cell* current = rowHead;
    for (int i =0 ; i < totalRows; ++i){
        cout << " " << std::setw(10) << "row " + to_string(i) + " " << " " ;
        cout << "|" << std::setw(10) << current->value << "|" << endl;
        current = current->next;
        cout << doubleline + line << endl;
    }

    cout << endl;

}
