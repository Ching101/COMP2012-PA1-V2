#include "Table.h"

// Task 9
Table::Table()
{
    this->totalColumns = 0;
    this->columnHead = nullptr;
}

// Task 10
Table::~Table()
{
    while (columnHead != nullptr) {
        Column* temp = columnHead;
        columnHead = columnHead->next;
        delete temp;
    }
}

// Task 11
Column* Table::findColumn(int colNum) const
{
    if (colNum+1 > totalColumns) {
        return nullptr;
    }
    Column* current = columnHead;
    int i = 0;
    while (i < colNum)
    {
        current = current->next;
        i++;
    }
    return current;
}

// Task 12
void Table::copyInsertColumn(int fromColNum, int toColNum)
{

}

// Task 13
void Table::deleteColumn(int colNum)
{

}

// Task 14
Cell *Table::findCell(int colNum, int rowNum) const
{   
    Column* col = findColumn(colNum);
    if (col == nullptr) {
        return nullptr;
    }
    return col->findCell(rowNum);
}

// Task 15
void Table::modifyCell(int colNum, int rowNum, const string &value)
{
    if (colNum < totalColumns) {
        Column* col = findColumn(colNum);
        if (col == nullptr) {
            return;
        }
        col->modifyCell(rowNum, value);
    } else {
        Column* current = columnHead;
        for (int i = 0;i < colNum; i++) {
            if (i+1 >= totalColumns) {
                Column* newCol = new Column();
                current->next = newCol;
                newCol->prev = current;
            }
            current = current -> next;
        }
        // last column, i.e. current = colNum
        current->modifyCell(rowNum, value);
        totalColumns = colNum+1;
    }
}

// Task 16
void Table::clearCell(int colNum, int rowNum)
{
    Cell* cell = findCell(colNum, rowNum);
    if (cell == nullptr) {
        return;
    }
    if (colNum < totalColumns) {
        Column* col = findColumn(colNum);
        if (col == nullptr) {
            return;
        }
        col->clearCell(rowNum);
        if (colNum+1 == totalColumns) {
            // the function also checks if the previous Column is also empty. If the previous Column is empty, a recursive deletion of empty columns
            
        }
    }
}

// ---------------------- provided functions: DO NOT MODIFY --------------------------
void Table::printTable() const
{

    // find the max number of rows
    int maxRows = 0;
    Column *currCol = columnHead;
    while (currCol != nullptr)
    {
        if (currCol->getTotalRows() > maxRows)
        {
            maxRows = currCol->getTotalRows();
        }
        currCol = currCol->next;
    }

    cout << "totalColumns: " << totalColumns << "\t ";
    cout << "maxRows: " << maxRows << endl;


    // string styles
    string line(12, '-');
    string doubleline(12, '=');
    string space(12, ' ');
    string headerline((totalColumns+1)*12, '=');


    // print table table header
    cout << headerline << endl;
    cout << " " << std::setw(10) << "" << "|";
    for (int i = 0; i < totalColumns; ++i)
    {
        cout<< "|" << std::setw(10) << "column "+to_string(i)+ " " << "|";
    }
    cout << endl;
    cout << headerline << endl;
    

    // print table body (row by row)
    string hline;
    for (int i = 0; i < maxRows; ++i)
    {
        hline = doubleline;    
        cout<< " " << std::setw(10) << "row "+to_string(i) + "  "<< " ";


        currCol = columnHead;

        while (currCol != nullptr)
        {
            Cell *currCell = currCol->findCell(i);
            if (currCell == nullptr)
            {
                hline += space;
                cout << " "<< std::setw(10) <<"" << " ";
            }
            else
            {
                hline += line;
                cout << "|" << std::setw(10) << currCell->value << "|";
            }
            currCol = currCol->next;
        }
        cout << endl;

        cout << hline << endl;
    }

    cout << endl;
    return;

}
